# 💸 SpendLens — Expense Tracker (Netlify Edition)

This is your expense tracker rebuilt as a **100% static web app** that deploys instantly to Netlify.

## What changed from the Flask version?

| Flask version | Netlify version |
|---|---|
| Python / Flask server | Pure HTML + JavaScript |
| SQLite database (server-side) | Browser `localStorage` (per-device) |
| Server-side sessions | JS session state |
| Werkzeug password hashing | Web Crypto API (SHA-256) |

All features are preserved:
- ✅ Multi-user login & signup
- ✅ Add / delete expenses
- ✅ Category + payment method tracking
- ✅ Monthly budgets with progress bars
- ✅ Dashboard with stats
- ✅ Charts (daily, category, 6-month trend)
- ✅ CSV export
- ✅ Mobile responsive

> **Note:** Because data is stored in `localStorage`, each user's data lives in their browser on that device. It does not sync across devices. For cross-device sync, you'd need a backend (PythonAnywhere, Render, etc.).

---

## Deploy to Netlify in 3 steps

### Option A — Drag & Drop (fastest, no account needed beyond Netlify)

1. Go to [app.netlify.com](https://app.netlify.com)
2. Sign up / log in
3. Drag the entire `netlify-expense/` folder onto the Netlify dashboard
4. Done — your app is live! 🎉

### Option B — Git deploy (recommended for ongoing updates)

1. Push this folder to a GitHub/GitLab repo
2. In Netlify: **Add new site → Import an existing project**
3. Connect your repo
4. Build settings:
   - **Build command:** *(leave empty)*
   - **Publish directory:** `.`
5. Click **Deploy site**

---

## Local preview

Just open `index.html` in any browser — no server needed!
